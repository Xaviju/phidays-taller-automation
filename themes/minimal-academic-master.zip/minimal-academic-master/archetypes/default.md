---
title: "{{ replace .Name "-" " " | title }}"
hero_image: "hero.jpg"
date: {{ .Date }}
draft: true
---

## Header